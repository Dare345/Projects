Components Used:
Menu-Used for the navigation menu at the top 
Accordion- Used in making the Degrees and Minors Sections to make dropdowns with information in them
GridV2-Used to format the minor accordions
Tabs-Used in people and employment table
Table-Table used to provide the list of information of CO-OP and Professional Employment
Pagination- used with the table making it easier to navigate through the information
Popover- used to display the classes for the minors when you click on them

Links:
Menu:https://react.semantic-ui.com/collections/menu/#types-props
Accordion:https://mui.com/material-ui/react-accordion/
GridV2:https://mui.com/material-ui/react-grid2/
Tabs:https://react.semantic-ui.com/modules/tab/
Table:https://mui.com/material-ui/react-table/
Pagination:https://mui.com/material-ui/react-pagination/
Popover:https://mui.com/material-ui/react-popover/#basic-popover 
URL:https://people.rit.edu/dy4385/340/viteReact/index.html