<!DOCTYPE html>
<html lang="en">
    <!-- Darren Yang, ISTE-240, 2238, 6/4/2024 -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo $path?>assets/css/styles.css" rel="stylesheet">
    <script src="<?php echo $path?>assets/javascript/project.js"></script>
    <title><?php echo $page?></title>
</head>
<body>