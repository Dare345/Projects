<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>ISTE-240</title>
	<style>
		/****************************************************/
		/*	Start - You won't need to mess with these rules	*/
		*, *:before, *:after {box-sizing: border-box;}
		.columnsContainer, footer, header { position: relative; margin: .5em; }
		.leftColumn, .rightColumn, footer, header {  border: 1px solid  #ccc; padding: 1.25em; }
		.leftColumn { margin-bottom: .5em; background-color:#E6A320}
		.rightColumn {background-color:#9EB40D}
		footer {background-color:#9692FE}
		header {background-color:#E64320}
		/*	End - You won't need to mess with these rules	*/
		/****************************************************/
		
		/****************************************************/
		/* Write your rules below!!! */
		
		
		/* CSS #1 */
		/* make the first letter of every p tag 3.8 times bigger and purple */
		p::first-letter{
			font-size:380%;
			color:purple;
		}
		
		/* CSS #2 */
		/* animate the header tag so it slides down from above on load of the page */
		/* animation should happen over 2 seconds, be linear, start at time 0 and only happen once */
		/* think CSS animation using @keyframes */
		
		@keyframes anim{
			from {bottom:250px;}
			to {bottom:0px;}
		}

		header{
			position:relative;
			animation-name:anim;
			animation-duration: 2s;
		}

		/* CSS #3 */
		/* MEDIA QUERIES */
		/* when the page is greater than 800px wide, make the .leftColumn and .rightColumn display side by side*/
		@media screen and (min-width:800px){
			.columnsContainer{
				display:flex;
				flex-direction:row;
			}
		}

		
	</style>
	<script type="text/javascript">
		/* JavaScript functions go here */
		function change(){
			if (document.getElementById("click").innerHTML = "ISTE-240 2338 Final"){
				document.getElementById("click").innerHTML = "I changed it!";
			}else if(document.getElementById("click").innerHTML = "I changed it!"){
				document.getElementById("click").innerHTML = "ISTE-240 2338 Final";
			}
		}
		function changeA(){
			document.getElementById("click").addEventListener("click",change());
		}

		function picture(){
			document.getElementById("pic").src = "assets/img/dsb.jpg";
		}

		function picture2(){
			document.getElementById("pic").src = "assets/img/img.png";
		}

		function ch(){
			const name = document.forms["order"]["name"].value;
			const address = document.forms["order"]["address"].value;
			const many = document.forms["order"]["howMany"].value;
			
			if (name === "" || name === null){
				document.getElementById("name").style.borderColor = "red";
				return false;
			}else{
				document.getElementById("name").style.borderColor = "";
			}
			
			if(address === "" || address === null){
				document.getElementById("address").style.borderColor = "red";
				return false;
			}else{
				document.getElementById("address").style.borderColor = "";
			}

			if(many === "" || many === null){
				document.getElementById("howMany").style.borderColor = "red";
				return false;
			}else{
				document.getElementById("howMany").style.borderColor = "";
			}

			if ((name != null && name != "") && (address != null && name != "") && (many != null && many != "")){
				return true;
			}
		}


	</script>
</head>