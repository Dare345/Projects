<!DOCTYPE html>
<html lang="en">
    <!-- Page done by Darren Yang 8/5/2024 -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <Link href="assets/css/styles.css" rel="stylesheet">
    <script src="<?php echo $path?>assets/javascript/Group.js"></script>
    <title><?php echo $name ?></title>
</head>