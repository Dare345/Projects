<!-- Page done by Darren Yang 8/5/2024 -->
<?php
    $name = "QuizResults";
    include("assets/inc/header.php");
    include("assets/inc/nav.php");
?>
<body>
    <main>
        <div id="results">
            <h1>Quiz Results</h1>

            <?php
            $correct = 0;
            $q1 = $_POST['q1'];
            $q2 = $_POST['q2'];
            $q3 = $_POST['q3'];
            $q4 = $_POST['q4'];
            $q5 = $_POST['q5'];
            $q6 = $_POST['q6'];
            $q7 = $_POST['q7'];
            $q8 = $_POST['q8'];

            if ($q1 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 1 wrong</p>';
                
            }

            if ($q2 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 2 wrong</p>';
            }

            if ($q3 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 3 wrong</p>';
                
            }
            
            if ($q4 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 4 wrong</p>';
                
            }

            if ($q5 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 5 wrong</p>';
            }

            if ($q6 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 6 wrong</p>';
            }

            if ($q7 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 7 wrong</p>';
            }

            if ($q8 == 'correct'){
                $correct++;
            }else{
                echo'<p>You got question 8 wrong</p>';
            }



            echo '<p>You got ' . ((string)$correct) . ' out of 8 question correct!</p>';

            ?>
        </div>
    </main>
</body>

<?php
    include("assets/inc/footer.php");
?>
</html>